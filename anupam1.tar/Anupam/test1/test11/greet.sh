echo "inside test11 directory!!"
