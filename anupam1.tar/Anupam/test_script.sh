echo This is a dummy script that lists all the files in a directory!!
ls
 
